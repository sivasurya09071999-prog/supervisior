let mediaStream = null;
let userLocation = null;

navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } })
    .then(stream => {
        mediaStream = stream;
        document.getElementById("video").srcObject = stream;
        document.getElementById("regVideo").srcObject = stream;
    })
    .catch(err => {
        alert("Camera access is required for face login. Please allow camera permission.");
        console.error(err);
    });


function getLocation() {
    const status = document.getElementById("locationStatus");
    if (navigator.geolocation) {
        status.textContent = "Detecting your location...";
        status.style.color = "#00b1f2";

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;

                fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`)
                    .then(r => r.json())
                    .then(data => {
                        const address = data.address || {};

                        const road = address.road || address.pedestrian || address.footway || address.path || "Unknown Road";
                        // const suburb = address.suburb || address.neighbourhood || address.quarter || "Unknown Suburb";
                        const city = address.city || address.town || address.village || address.municipality || "Chennai";
                        const state = address.state || "Tamil Nadu";

                        // Avoid duplication (e.g., Chennai, Chennai)
                        let locationParts = [];
                        if (road !== "Unknown Road") locationParts.push(road);
                        if (suburb !== "Unknown Suburb" && suburb !== city) locationParts.push(suburb);
                        if (city) locationParts.push(city);
                        if (state) locationParts.push(state);

                        userLocation = locationParts.join(", ");

                        document.getElementById("locationInfo").innerHTML = `
                            <i class="fas fa-map-marker-alt"></i> 
                            <strong>Location:</strong> ${userLocation}
                        `;

                        document.getElementById("locationBox").classList.add("hidden");
                        document.getElementById("loginBox").classList.remove("hidden");
                        document.getElementById("luser").focus();
                    })
                    .catch(err => {
                        console.error("Location error:", err);
                        userLocation = "Mount Road, Chennai, Tamil Nadu";  // Fallback for Mount Road
                        document.getElementById("locationInfo").textContent = "Location: Mount Road, Chennai, Tamil Nadu";
                        document.getElementById("locationBox").classList.add("hidden");
                        document.getElementById("loginBox").classList.remove("hidden");
                        document.getElementById("luser").focus();
                    });
            },
            (error) => {
                status.textContent = "Location access denied or unavailable";
                status.style.color = "#ff4444";
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
        );
    } else {
        status.textContent = "Geolocation not supported";
        status.style.color = "#ff4444";
    }
}


function register() {
    const username = document.getElementById("ruser").value.trim().toLowerCase();
    const email = document.getElementById("remail").value.trim().toLowerCase();  // ← MUST READ THIS
    const password = document.getElementById("rpass").value;
    const confirm = document.getElementById("rconfirm").value;
    const role = document.getElementById("rrole").value;
    const image = capture("regVideo", "regCanvas");
    const errorEl = document.getElementById("regError");
    const btn = document.querySelector("#registerBox button");

    if (!username || !email || !password || !confirm || !role) {
        errorEl.textContent = "All fields are required";
        return;
    }
    if (password !== confirm) {
        errorEl.textContent = "Passwords do not match";
        return;
    }

    btn.disabled = true;
    btn.textContent = "Capturing face...";
    errorEl.textContent = "Look straight at the camera";

    fetch("/register-with-face", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            username: username,
            email: email,          // ← MUST SEND THIS
            password: password,
            role: role,
            image: image,
            location: userLocation || "Unknown Location"
        })
    })
        .then(r => r.json())
        .then(d => {
            if (d.status === "success") {
                errorEl.textContent = "Registered successfully! Redirecting...";
                errorEl.style.color = "#00ff00";
                if (mediaStream) mediaStream.getTracks().forEach(t => t.stop());
                setTimeout(() => window.location = "/dashboard", 1500);
            } else {
                errorEl.textContent = d.message || "Registration failed";
                errorEl.style.color = "#ff4444";
            }
        })
        .catch(() => {
            errorEl.textContent = "Network error";
            errorEl.style.color = "#ff4444";
        })
        .finally(() => {
            btn.disabled = false;
            btn.textContent = "CAPTURE FACE & REGISTER";
        });
}

function showRegister() {
    document.getElementById("loginBox").classList.add("hidden");
    document.getElementById("registerBox").classList.remove("hidden");
    document.getElementById("ruser").focus();
}

function showLogin() {
    document.getElementById("registerBox").classList.add("hidden");
    document.getElementById("loginBox").classList.remove("hidden");
    document.getElementById("luser").focus();
}

function capture(videoId, canvasId) {
    const video = document.getElementById(videoId);
    const canvas = document.getElementById(canvasId);
    const width = video.videoWidth || 640;
    const height = video.videoHeight || 480;
    canvas.width = width;
    canvas.height = height;
    canvas.getContext('2d').drawImage(video, 0, 0, width, height);
    return canvas.toDataURL("image/jpeg", 0.8);
}

function faceLogin() {
    const username = document.getElementById("luser").value.trim();
    const password = document.getElementById("lpass").value;
    const errorEl = document.getElementById("loginError");
    const btn = document.querySelector("#loginBox button");

    if (!username || !password) {
        errorEl.textContent = "Please enter username and password";
        return;
    }

    if (!userLocation) {
        errorEl.textContent = "Location not detected. Please allow location access.";
        return;
    }

    btn.disabled = true;
    btn.textContent = "Verifying face...";
    errorEl.textContent = "Look straight at the camera";

    const image = capture("video", "canvas");

    fetch("/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            username,
            password,
            image,
            location: userLocation  // ← Send location to backend
        })
    })
        .then(r => r.json())
        .then(d => {
            if (d.status === "success") {
                errorEl.textContent = "Login successful! Welcome back.";
                errorEl.style.color = "#00ff00";
                if (mediaStream) mediaStream.getTracks().forEach(t => t.stop());
                setTimeout(() => window.location = "/dashboard", 1500);
            } else {
                errorEl.textContent = d.message || "Login failed";
                errorEl.style.color = "#ff4444";
            }
        })
        .catch(() => {
            errorEl.textContent = "Network error. Try again.";
            errorEl.style.color = "#ff4444";
        })
        .finally(() => {
            btn.disabled = false;
            btn.textContent = "VERIFY FACE & LOGIN";
        });
}


// let mediaStream = null;

// navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } })
//     .then(stream => {
//         mediaStream = stream;
//         document.getElementById("video").srcObject = stream;
//         document.getElementById("regVideo").srcObject = stream;
//     })
//     .catch(err => {
//         alert("Camera access is required for face login. Please allow camera permission.");
//         console.error(err);
//     });

// function showRegister() {
//     document.getElementById("loginBox").classList.add("hidden");
//     document.getElementById("registerBox").classList.remove("hidden");
//     document.getElementById("ruser").focus();
// }

// function showLogin() {
//     document.getElementById("registerBox").classList.add("hidden");
//     document.getElementById("loginBox").classList.remove("hidden");
//     document.getElementById("luser").focus();
// }

// function capture(videoId, canvasId) {
//     const video = document.getElementById(videoId);
//     const canvas = document.getElementById(canvasId);
//     const width = video.videoWidth || 640;
//     const height = video.videoHeight || 480;
//     canvas.width = width;
//     canvas.height = height;
//     canvas.getContext('2d').drawImage(video, 0, 0, width, height);
//     return canvas.toDataURL("image/jpeg", 0.8);
// }

// function faceLogin() {
//     const username = document.getElementById("luser").value.trim();
//     const password = document.getElementById("lpass").value;
//     const errorEl = document.getElementById("loginError");
//     const btn = document.querySelector("#loginBox button");

//     if (!username || !password) {
//         errorEl.textContent = "Please enter username and password";
//         return;
//     }

//     btn.disabled = true;
//     btn.textContent = "Verifying face...";
//     errorEl.textContent = "Look straight at the camera";

//     const image = capture("video", "canvas");

//     fetch("/login", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ username, password, image })
//     })
//         .then(r => r.json())
//         .then(d => {
//             if (d.status === "success") {
//                 errorEl.textContent = "Login successful! Redirecting...";
//                 if (mediaStream) mediaStream.getTracks().forEach(t => t.stop());
//                 setTimeout(() => window.location = "/dashboard", 1000);
//             } else {
//                 errorEl.textContent = d.message === "Face not matched"
//                     ? "Face not recognized. Try again or adjust lighting."
//                     : d.message || "Login failed";
//             }
//         })
//         .catch(() => errorEl.textContent = "Network error. Check connection.")
//         .finally(() => {
//             btn.disabled = false;
//             btn.textContent = "VERIFY FACE & LOGIN";
//         });
// }

// function register() {
//     const username = document.getElementById("ruser").value.trim();
//     const password = document.getElementById("rpass").value;
//     const confirm = document.getElementById("rconfirm").value;
//     const role = document.getElementById("rrole").value;
//     const image = capture("regVideo", "regCanvas");
//     const errorEl = document.getElementById("regError");
//     const btn = document.querySelector("#registerBox button");

//     if (!username || !password || !confirm || !role) {
//         errorEl.textContent = "All fields are required";
//         return;
//     }
//     if (password !== confirm) {
//         errorEl.textContent = "Passwords do not match";
//         return;
//     }

//     btn.disabled = true;
//     btn.textContent = "Capturing face...";
//     errorEl.textContent = "Look straight at the camera";

//     fetch("/register-with-face", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ username, password, role, image })
//     })
//         .then(r => r.json())
//         .then(d => {
//             if (d.status === "success") {
//                 errorEl.textContent = "Registered successfully! Redirecting...";
//                 if (mediaStream) mediaStream.getTracks().forEach(t => t.stop());
//                 setTimeout(() => window.location = "/dashboard", 1000);
//             } else {
//                 errorEl.textContent = d.message || "Registration failed";
//             }
//         })
//         .catch(() => errorEl.textContent = "Network error")
//         .finally(() => {
//             btn.disabled = false;
//             btn.textContent = "CAPTURE FACE & REGISTER";
//         });
// }