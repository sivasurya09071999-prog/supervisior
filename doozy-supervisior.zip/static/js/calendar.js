let progressChart = null;

function loadDashboard() {
    fetch("/dashboard-data")
        .then(r => r.json())
        .then(d => {
            // Attendance Table
            const tbody = document.querySelector("#attendanceTable");
            tbody.innerHTML = "";
            d.attendance.forEach(day => {
                const tr = document.createElement("tr");
                tr.innerHTML = `<td>${day.date}</td><td>${day.first_in}</td><td>${day.last_out}</td><td>${day.hours}</td>`;
                tbody.appendChild(tr);
            });

            // Task Progress
            const taskName = d.task_name || "No task today";
            const progressValue = parseInt(d.task_progress) || 0;

            document.getElementById("taskNameDisplay").textContent = taskName;
            document.getElementById("progressText").textContent = progressValue + "%";

            const ctx = document.getElementById("progressChart").getContext("2d");
            if (!progressChart) {
                progressChart = new Chart(ctx, {
                    type: "doughnut",
                    data: {
                        datasets: [{
                            data: [progressValue, 100 - progressValue],
                            backgroundColor: ["#00b1f2", "rgba(255,255,255,0.05)"],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        cutout: "70%",
                        plugins: { legend: { display: false } },
                        rotation: -90,
                        circumference: 360
                    }
                });
            } else {
                progressChart.data.datasets[0].data = [progressValue, 100 - progressValue];
                progressChart.update();
            }
        })
        .catch(err => console.error("Dashboard load error:", err));
}

function saveTask() {
    const task = document.getElementById("taskDesc").value.trim();
    const progressInput = document.getElementById("taskProgress").value;
    const progress = parseInt(progressInput);

    if (!task) return alert("Please enter a task description");
    if (isNaN(progress) || progress < 0 || progress > 100) return alert("Progress must be 0–100");

    fetch("/task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task, progress: progress + "%" })
    })
        .then(() => {
            alert("Task saved successfully!");
            document.getElementById("taskDesc").value = "";
            document.getElementById("taskProgress").value = "";
            loadDashboard();
        })
        .catch(() => alert("Failed to save task"));
}

function askHR() {
    const q = document.getElementById("hrQuestion").value.trim();
    if (!q) return;

    const log = document.getElementById("chatLog");
    const btn = document.querySelector(".ai-button");
    btn.disabled = true;
    btn.textContent = "Thinking...";

    log.innerHTML += `<p><strong>You:</strong> ${q}</p>`;
    log.innerHTML += `<p><strong>Doozy AI:</strong> <em>thinking...</em></p>`;
    log.scrollTop = log.scrollHeight;

    fetch("/ask-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: q })
    })
        .then(r => r.json())
        .then(d => {
            log.lastElementChild.innerHTML = `<strong>Doozy AI:</strong> ${d.answer.replace(/\n/g, '<br>')}`;
            log.scrollTop = log.scrollHeight;
            document.getElementById("hrQuestion").value = "";
        })
        .catch(() => {
            log.lastElementChild.innerHTML = `<strong>Doozy AI:</strong> <span style="color:#ff6b6b">Unavailable now</span>`;
        })
        .finally(() => {
            btn.disabled = false;
            btn.textContent = "ASK DOOZY AI";
        });
}

function logout() {
    fetch("/logout")
        .then(() => window.location.href = "/login")
        .catch(() => window.location.href = "/login");
}

// Load on start and refresh every minute
loadDashboard();
setInterval(loadDashboard, 60000);