let progressChart = null;

// === Load Dashboard Data ===
function loadDashboard() {
    fetch("/dashboard-data")
        .then(r => r.json())
        .then(d => {
            // Attendance Table
            const tbody = document.querySelector("#attendanceTable");
            tbody.innerHTML = "";
            d.attendance.forEach(day => {
                const tr = document.createElement("tr");
                tr.innerHTML = `<td>${day.date}</td><td>${day.first_in}</td><td>${day.last_out}</td><td>${day.hours}</td>`;
                tbody.appendChild(tr);
            });

            // Task Progress
            let taskName = d.task_name || "No task assigned yet";
            let progressValue = parseInt(d.task_progress) || 0;

            document.getElementById("taskNameDisplay").textContent = taskName;
            document.getElementById("progressText").textContent = progressValue + "%";

            // Style old task
            if (taskName.includes("Last updated")) {
                document.getElementById("taskNameDisplay").style.fontSize = "18px";
                document.getElementById("taskNameDisplay").style.opacity = "0.85";
                document.getElementById("taskNameDisplay").style.fontStyle = "italic";
            } else {
                document.getElementById("taskNameDisplay").style.fontSize = "22px";
                document.getElementById("taskNameDisplay").style.opacity = "1";
                document.getElementById("taskNameDisplay").style.fontStyle = "normal";
            }

            // Doughnut Chart
            const ctx = document.getElementById("progressChart").getContext("2d");
            if (!progressChart) {
                progressChart = new Chart(ctx, {
                    type: "doughnut",
                    data: {
                        datasets: [{
                            data: [progressValue, 100 - progressValue],
                            backgroundColor: ["#00b1f2", "rgba(255,255,255,0.05)"],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        cutout: "70%",
                        plugins: { legend: { display: false } },
                        rotation: -90,
                        circumference: 360
                    }
                });
            } else {
                progressChart.data.datasets[0].data = [progressValue, 100 - progressValue];
                progressChart.update();
            }

            // Update Header: Username & Role
            document.getElementById("usernameDisplay").textContent = d.username || "User";
            document.getElementById("roleDisplay").textContent = d.role || "Employee";
        })
        .catch(err => {
            console.error("Dashboard load error:", err);
            document.getElementById("usernameDisplay").textContent = "Error";
            document.getElementById("roleDisplay").textContent = "Offline";
        });
}

// === Save Task ===
function saveTask() {
    const task = document.getElementById("taskDesc").value.trim();
    const progressInput = document.getElementById("taskProgress").value;
    const progress = parseInt(progressInput);

    if (!task) return alert("Please enter a task description");
    if (isNaN(progress) || progress < 0 || progress > 100) return alert("Progress must be 0–100");

    fetch("/task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task, progress: progress + "%" })
    })
    .then(() => {
        alert("Task saved successfully!");
        document.getElementById("taskDesc").value = "";
        document.getElementById("taskProgress").value = "";
        loadDashboard();
    })
    .catch(() => alert("Failed to save task"));
}

// === Ask AI ===
function askHR() {
    const q = document.getElementById("hrQuestion").value.trim();
    if (!q) return;

    const log = document.getElementById("chatLog");
    const btn = document.querySelector(".ai-button");
    btn.disabled = true;
    btn.textContent = "Thinking...";

    log.innerHTML += `<p><strong>You:</strong> ${q}</p>`;
    log.innerHTML += `<p><strong>Doozy AI:</strong> <em>thinking...</em></p>`;
    log.scrollTop = log.scrollHeight;

    fetch("/ask-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: q })
    })
    .then(r => r.json())
    .then(d => {
        log.lastElementChild.innerHTML = `<strong>Doozy AI:</strong> ${d.answer.replace(/\n/g, '<br>')}`;
        log.scrollTop = log.scrollHeight;
        document.getElementById("hrQuestion").value = "";
    })
    .catch(() => {
        log.lastElementChild.innerHTML = `<strong>Doozy AI:</strong> <span style="color:#ff6b6b">Unavailable now</span>`;
    })
    .finally(() => {
        btn.disabled = false;
        btn.textContent = "ASK DOOZY AI";
    });
}

// === Logout ===
function logout() {
    fetch("/logout")
        .then(() => window.location.href = "/login")
        .catch(() => window.location.href = "/login");
}

// === CALENDAR VARIABLES ===
let currentMonth = new Date().getMonth();
let currentYear = new Date().getFullYear();
let presentDates = {}, leaveDates = {}, permissionDates = [], govHolidays = [];
let selectedDate = null;

// === Open Calendar ===
function openAttendanceCalendar() {
    document.getElementById("attendanceModal").style.display = "flex";
    fetch("/attendance-calendar-data")
        .then(r => r.json())
        .then(data => {
            presentDates = data.present_dates || {};
            leaveDates = data.leave_dates || {};
            permissionDates = data.permission_dates || [];
            govHolidays = data.gov_holidays || [];
            renderCalendar();
        })
        .catch(err => {
            console.error("Calendar data error:", err);
            alert("Failed to load calendar data");
        });
}

// === Close Calendar ===
function closeAttendanceCalendar() {
    document.getElementById("attendanceModal").style.display = "none";
    document.getElementById("dayDetails").style.display = "none";
    document.getElementById("leaveForm").style.display = "none";
    document.getElementById("leaveMessage").textContent = "";
}

// === Render Calendar ===
function renderCalendar() {
    const container = document.getElementById("calendarDays");
    container.innerHTML = "";
    document.getElementById("monthYear").textContent = new Date(currentYear, currentMonth)
        .toLocaleString('default', { month: 'long', year: 'numeric' });

    const firstDay = new Date(currentYear, currentMonth, 1).getDay();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const today = new Date().toISOString().split('T')[0];

    for (let i = 0; i < firstDay; i++) {
        container.innerHTML += `<div></div>`;
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const dateObj = new Date(currentYear, currentMonth, day);

        const classes = [
            "day",
            dateObj.getDay() === 0 ? "sunday" : "",
            govHolidays.includes(dateStr) ? "gov-holiday" : "",
            presentDates[dateStr] ? "present" : "",
            leaveDates[dateStr] ? "leave" : "",
            permissionDates.includes(dateStr) ? "permission" : "",
            dateStr === today ? "today" : ""
        ].filter(Boolean).join(" ");

        const el = document.createElement("div");
        el.className = classes;
        el.textContent = day;
        if (govHolidays.includes(dateStr)) el.title = "Government Holiday";
        el.onclick = () => selectDay(dateStr, !!presentDates[dateStr] || !!leaveDates[dateStr] || permissionDates.includes(dateStr), dateObj > new Date());
        container.appendChild(el);
    }
}

// === Select Day - Smart Panel Logic ===
function selectDay(dateStr, hasRecord, isFuture) {
    selectedDate = dateStr;
    document.getElementById("selectedDateTitle").textContent = `Date: ${new Date(dateStr).toDateString()}`;
    document.getElementById("leaveDateDisplay").textContent = new Date(dateStr).toDateString();

    document.getElementById("dayDetails").style.display = "none";
    document.getElementById("leaveForm").style.display = "none";
    document.getElementById("leaveMessage").textContent = "";

    if (presentDates[dateStr]) {
        document.getElementById("firstIn").textContent = presentDates[dateStr].in || "-";
        document.getElementById("lastOut").textContent = presentDates[dateStr].out || "-";
        document.getElementById("dayDetails").style.display = "block";

    } else if (leaveDates[dateStr] || permissionDates.includes(dateStr)) {
        const currentType = leaveDates[dateStr] || (permissionDates.includes(dateStr) ? "Permission" : "");

        document.getElementById("leaveForm").innerHTML = `
            <h3>Manage Leave for <span id="leaveDateDisplay">${new Date(dateStr).toDateString()}</span></h3>
            <p><strong>Current Status:</strong> <span style="color:#ffff00; font-weight:bold;">${currentType}</span></p>
            
            <select id="leaveType">
                <option value="">Change Type (Optional)</option>
                <option value="Pre-planned Leave">Pre-planned Leave</option>
                <option value="Emergency Leave">Emergency Leave</option>
                <option value="Permission">Permission</option>
            </select>
            
            <textarea id="leavePurpose" placeholder="Update purpose (optional)..."></textarea>
            
            <div style="display:flex; gap:15px; margin-top:20px;">
                <button onclick="submitLeave()" style="flex:1; background:#00b1f2; border:none; padding:14px; border-radius:12px; color:white; font-weight:bold;">
                    UPDATE LEAVE
                </button>
                <button onclick="cancelLeave('${dateStr}')" style="flex:1; background:#ff4444; border:none; padding:14px; border-radius:12px; color:white; font-weight:bold;">
                    CANCEL LEAVE
                </button>
            </div>
            <p id="leaveMessage" style="margin-top:15px;"></p>
        `;

        document.getElementById("leaveType").value = currentType;
        document.getElementById("leaveForm").style.display = "block";

    } else if (isFuture) {
        document.getElementById("leaveForm").innerHTML = `
            <h3>Apply Leave for <span id="leaveDateDisplay">${new Date(dateStr).toDateString()}</span></h3>
            <select id="leaveType">
                <option value="">Select Type</option>
                <option value="Pre-planned Leave">Pre-planned Leave</option>
                <option value="Emergency Leave">Emergency Leave</option>
                <option value="Permission">Permission</option>
            </select>
            <textarea id="leavePurpose" placeholder="Purpose of leave..."></textarea>
            <button onclick="submitLeave()" style="width:100%; margin-top:15px; background:#00b1f2; border:none; padding:16px; border-radius:14px; color:white; font-weight:bold;">
                SUBMIT APPLICATION
            </button>
            <p id="leaveMessage"></p>
        `;
        document.getElementById("leaveForm").style.display = "block";

    } else {
        document.getElementById("firstIn").textContent = "Absent";
        document.getElementById("lastOut").textContent = "-";
        document.getElementById("dayDetails").style.display = "block";
    }
}

// === Submit Leave (Apply or Update) ===
function submitLeave() {
    const type = document.getElementById("leaveType").value;
    const purpose = document.getElementById("leavePurpose").value.trim();

    if (!type) {
        document.getElementById("leaveMessage").textContent = "Please select a leave type";
        document.getElementById("leaveMessage").style.color = "#ff6b6b";
        return;
    }

    fetch("/apply-leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: selectedDate, type, purpose: purpose || "No purpose" })
    })
    .then(r => r.json())
    .then(d => {
        document.getElementById("leaveMessage").style.color = d.status === "success" ? "#00b1f2" : "#ff6b6b";
        document.getElementById("leaveMessage").textContent = d.message;

        if (d.status === "success") {
            setTimeout(() => {
                closeAttendanceCalendar();
                openAttendanceCalendar();
            }, 1500);
        }
    });
}

// === Cancel Leave ===
function cancelLeave(dateStr) {
    if (!confirm("Are you sure you want to CANCEL this leave/permission?\nThis cannot be undone.")) return;

    fetch("/cancel-leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: dateStr })
    })
    .then(r => r.json())
    .then(d => {
        document.getElementById("leaveMessage").style.color = d.status === "success" ? "#00b1f2" : "#ff6b6b";
        document.getElementById("leaveMessage").textContent = d.message;

        if (d.status === "success") {
            setTimeout(() => {
                closeAttendanceCalendar();
                openAttendanceCalendar();
            }, 1500);
        }
    });
}

// === Month Navigation ===
function prevMonth() {
    currentMonth--;
    if (currentMonth < 0) { currentMonth = 11; currentYear--; }
    renderCalendar();
}

function nextMonth() {
    currentMonth++;
    if (currentMonth > 11) { currentMonth = 0; currentYear++; }
    renderCalendar();
}

// === Initialize on Page Load ===
loadDashboard();
setInterval(loadDashboard, 60000); // Refresh dashboard every minute

// Remove old summary
const oldSummary = document.querySelector(".month-summary-card");
if (oldSummary) oldSummary.remove();

// === Show Popup Message ===
function showPopup(message, isSuccess = true) {
    // Remove old popup if exists
    const oldPopup = document.getElementById("popupMessage");
    if (oldPopup) oldPopup.remove();

    const popup = document.createElement("div");
    popup.id = "popupMessage";
    popup.textContent = message;
    popup.style.position = "fixed";
    popup.style.bottom = "30px";
    popup.style.right = "30px";
    popup.style.padding = "20px 30px";
    popup.style.background = isSuccess ? "linear-gradient(135deg, #00b1f2, #0081c2)" : "#ff4444";
    popup.style.color = "white";
    popup.style.borderRadius = "16px";
    popup.style.boxShadow = "0 0 30px rgba(0, 177, 242, 0.6)";
    popup.style.zIndex = "2000";
    popup.style.fontSize = "18px";
    popup.style.fontWeight = "bold";
    popup.style.animation = "slideIn 0.5s ease-out";

    document.body.appendChild(popup);

    // Auto remove after 3 seconds
    setTimeout(() => {
        popup.style.animation = "slideOut 0.5s ease-in";
        setTimeout(() => popup.remove(), 500);
    }, 3000);
}

// Add CSS animations (add to dashboard.css)
const style = document.createElement("style");
style.textContent = `
@keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}
@keyframes slideOut {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
}
`;
document.head.appendChild(style);

// === Submit Leave (Apply or Update) ===
function submitLeave() {
    const type = document.getElementById("leaveType").value;
    const purpose = document.getElementById("leavePurpose").value.trim();

    if (!type) {
        showPopup("Please select a leave type", false);
        return;
    }

    fetch("/apply-leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: selectedDate, type, purpose: purpose || "No purpose" })
    })
    .then(r => r.json())
    .then(d => {
        showPopup(d.message, d.status === "success");
        if (d.status === "success") {
            setTimeout(() => {
                closeAttendanceCalendar();
                openAttendanceCalendar();
            }, 1500);
        }
    })
    .catch(() => showPopup("Network error", false));
}

// === Cancel Leave ===
function cancelLeave(dateStr) {
    if (!confirm("Are you sure you want to CANCEL this leave/permission?\nThis cannot be undone.")) return;

    fetch("/cancel-leave", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: dateStr })
    })
    .then(r => r.json())
    .then(d => {
        showPopup(d.message, d.status === "success");
        if (d.status === "success") {
            setTimeout(() => {
                closeAttendanceCalendar();
                openAttendanceCalendar();
            }, 1500);
        }
    })
    .catch(() => showPopup("Network error", false));
}

function showMonthlyStatus() {
    fetch("/attendance-calendar-data")
        .then(r => r.json())
        .then(data => {
            const summary = data.month_summary || {};
            const monthName = summary.month_name || new Date().toLocaleString('default', { month: 'long', year: 'numeric' });
            const asOf = summary.as_of || "Today";

            document.getElementById("monthlyStatusContent").innerHTML = `
                <h3 style="color:#00b1f2; margin-bottom:20px;">${monthName}</h3>
                <p style="font-size:16px; margin:10px 0;"><strong>So far as of:</strong> ${asOf}</p>
                
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin:30px 0;">
                    <div style="background:rgba(0,255,0,0.1); padding:20px; border-radius:16px; border:2px solid #00ff00;">
                        <p style="margin:5px 0; color:#a0d8ff;">Working Days So Far</p>
                        <p style="font-size:32px; font-weight:bold; color:white; margin:0;">${summary.working_days_so_far || 0}</p>
                    </div>
                    <div style="background:rgba(0,255,255,0.1); padding:20px; border-radius:16px; border:2px solid #00ffff;">
                        <p style="margin:5px 0; color:#a0d8ff;">Present</p>
                        <p style="font-size:32px; font-weight:bold; color:#00ff00; margin:0;">${summary.present || 0}</p>
                    </div>
                    <div style="background:rgba(255,255,0,0.1); padding:20px; border-radius:16px; border:2px solid #ffff00;">
                        <p style="margin:5px 0; color:#a0d8ff;">Leave/Permission</p>
                        <p style="font-size:32px; font-weight:bold; color:#ffff00; margin:0;">${summary.leave || 0}</p>
                    </div>
                    <div style="background:rgba(255,0,0,0.1); padding:20px; border-radius:16px; border:2px solid #ff6b6b;">
                        <p style="margin:5px 0; color:#a0d8ff;">Absent</p>
                        <p style="font-size:32px; font-weight:bold; color:#ff6b6b; margin:0;">${summary.absent || 0}</p>
                    </div>
                </div>


            `;

            document.getElementById("monthlyStatusModal").style.display = "flex";
        })
        .catch(err => {
            console.error("Monthly status error:", err);
            document.getElementById("monthlyStatusContent").innerHTML = "<p style='color:#ff6b6b;'>Failed to load status</p>";
            document.getElementById("monthlyStatusModal").style.display = "flex";
        });
}

function closeMonthlyStatus() {
    document.getElementById("monthlyStatusModal").style.display = "none";
}

// let progressChart = null;

// // === Load Dashboard Data ===
// function loadDashboard() {
//     fetch("/dashboard-data")
//         .then(r => r.json())
//         .then(d => {
//             // Attendance Table
//             const tbody = document.querySelector("#attendanceTable");
//             tbody.innerHTML = "";
//             d.attendance.forEach(day => {
//                 const tr = document.createElement("tr");
//                 tr.innerHTML = `<td>${day.date}</td><td>${day.first_in}</td><td>${day.last_out}</td><td>${day.hours}</td>`;
//                 tbody.appendChild(tr);
//             });

//             // Task Progress
//             let taskName = d.task_name || "No task assigned yet";
//             let progressValue = parseInt(d.task_progress) || 0;

//             document.getElementById("taskNameDisplay").textContent = taskName;
//             document.getElementById("progressText").textContent = progressValue + "%";

//             // Style old task
//             if (taskName.includes("Last updated")) {
//                 document.getElementById("taskNameDisplay").style.fontSize = "18px";
//                 document.getElementById("taskNameDisplay").style.opacity = "0.85";
//                 document.getElementById("taskNameDisplay").style.fontStyle = "italic";
//             } else {
//                 document.getElementById("taskNameDisplay").style.fontSize = "22px";
//                 document.getElementById("taskNameDisplay").style.opacity = "1";
//                 document.getElementById("taskNameDisplay").style.fontStyle = "normal";
//             }

//             // Doughnut Chart
//             const ctx = document.getElementById("progressChart").getContext("2d");
//             if (!progressChart) {
//                 progressChart = new Chart(ctx, {
//                     type: "doughnut",
//                     data: {
//                         datasets: [{
//                             data: [progressValue, 100 - progressValue],
//                             backgroundColor: ["#00b1f2", "rgba(255,255,255,0.05)"],
//                             borderWidth: 0
//                         }]
//                     },
//                     options: {
//                         cutout: "70%",
//                         plugins: { legend: { display: false } },
//                         rotation: -90,
//                         circumference: 360
//                     }
//                 });
//             } else {
//                 progressChart.data.datasets[0].data = [progressValue, 100 - progressValue];
//                 progressChart.update();
//             }

//             // Update Header: Username & Role
//             document.getElementById("usernameDisplay").textContent = d.username || "User";
//             document.getElementById("roleDisplay").textContent = d.role || "Employee";
//         })
//         .catch(err => {
//             console.error("Dashboard load error:", err);
//             document.getElementById("usernameDisplay").textContent = "Error";
//             document.getElementById("roleDisplay").textContent = "Offline";
//         });
// }

// // === Save Task ===
// function saveTask() {
//     const task = document.getElementById("taskDesc").value.trim();
//     const progressInput = document.getElementById("taskProgress").value;
//     const progress = parseInt(progressInput);

//     if (!task) return alert("Please enter a task description");
//     if (isNaN(progress) || progress < 0 || progress > 100) return alert("Progress must be 0–100");

//     fetch("/task", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ task, progress: progress + "%" })
//     })
//     .then(() => {
//         alert("Task saved successfully!");
//         document.getElementById("taskDesc").value = "";
//         document.getElementById("taskProgress").value = "";
//         loadDashboard();
//     })
//     .catch(() => alert("Failed to save task"));
// }

// // === Ask AI ===
// function askHR() {
//     const q = document.getElementById("hrQuestion").value.trim();
//     if (!q) return;

//     const log = document.getElementById("chatLog");
//     const btn = document.querySelector(".ai-button");
//     btn.disabled = true;
//     btn.textContent = "Thinking...";

//     log.innerHTML += `<p><strong>You:</strong> ${q}</p>`;
//     log.innerHTML += `<p><strong>Doozy AI:</strong> <em>thinking...</em></p>`;
//     log.scrollTop = log.scrollHeight;

//     fetch("/ask-ai", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ question: q })
//     })
//     .then(r => r.json())
//     .then(d => {
//         log.lastElementChild.innerHTML = `<strong>Doozy AI:</strong> ${d.answer.replace(/\n/g, '<br>')}`;
//         log.scrollTop = log.scrollHeight;
//         document.getElementById("hrQuestion").value = "";
//     })
//     .catch(() => {
//         log.lastElementChild.innerHTML = `<strong>Doozy AI:</strong> <span style="color:#ff6b6b">Unavailable now</span>`;
//     })
//     .finally(() => {
//         btn.disabled = false;
//         btn.textContent = "ASK DOOZY AI";
//     });
// }

// // === Logout ===
// function logout() {
//     fetch("/logout")
//         .then(() => window.location.href = "/login")
//         .catch(() => window.location.href = "/login");
// }

// // === CALENDAR VARIABLES ===
// let currentMonth = new Date().getMonth();
// let currentYear = new Date().getFullYear();
// let presentDates = {}, leaveDates = {}, permissionDates = [], govHolidays = [];
// let selectedDate = null;

// // === Open Calendar ===
// function openAttendanceCalendar() {
//     document.getElementById("attendanceModal").style.display = "flex";
//     fetch("/attendance-calendar-data")
//         .then(r => r.json())
//         .then(data => {
//             presentDates = data.present_dates || {};
//             leaveDates = data.leave_dates || {};
//             permissionDates = data.permission_dates || [];
//             govHolidays = data.gov_holidays || [];
//             renderCalendar();
//         })
//         .catch(err => {
//             console.error("Calendar data error:", err);
//             alert("Failed to load calendar data");
//         });
// }

// // === Close Calendar ===
// function closeAttendanceCalendar() {
//     document.getElementById("attendanceModal").style.display = "none";
//     document.getElementById("dayDetails").style.display = "none";
//     document.getElementById("leaveForm").style.display = "none";
//     document.getElementById("leaveMessage").textContent = "";
// }

// // === Render Calendar ===
// function renderCalendar() {
//     const container = document.getElementById("calendarDays");
//     container.innerHTML = "";
//     document.getElementById("monthYear").textContent = new Date(currentYear, currentMonth)
//         .toLocaleString('default', { month: 'long', year: 'numeric' });

//     const firstDay = new Date(currentYear, currentMonth, 1).getDay();
//     const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
//     const today = new Date().toISOString().split('T')[0];

//     // Empty cells before first day
//     for (let i = 0; i < firstDay; i++) {
//         container.innerHTML += `<div></div>`;
//     }

//     // Days
//     for (let day = 1; day <= daysInMonth; day++) {
//         const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
//         const dateObj = new Date(currentYear, currentMonth, day);

//         const classes = [
//             "day",
//             dateObj.getDay() === 0 ? "sunday" : "",
//             govHolidays.includes(dateStr) ? "gov-holiday" : "",
//             presentDates[dateStr] ? "present" : "",
//             leaveDates[dateStr] ? "leave" : "",
//             permissionDates.includes(dateStr) ? "permission" : "",
//             dateStr === today ? "today" : ""
//         ].filter(Boolean).join(" ");

//         const el = document.createElement("div");
//         el.className = classes;
//         el.textContent = day;
//         if (govHolidays.includes(dateStr)) el.title = "Government Holiday";
//         el.onclick = () => selectDay(dateStr, !!presentDates[dateStr] || !!leaveDates[dateStr] || permissionDates.includes(dateStr), dateObj > new Date());
//         container.appendChild(el);
//     }
// }

// // === Select Day - MAIN LOGIC ===
// function selectDay(dateStr, hasRecord, isFuture) {
//     selectedDate = dateStr;
//     document.getElementById("selectedDateTitle").textContent = `Date: ${new Date(dateStr).toDateString()}`;
//     document.getElementById("leaveDateDisplay").textContent = new Date(dateStr).toDateString();

//     // Reset
//     document.getElementById("dayDetails").style.display = "none";
//     document.getElementById("leaveForm").style.display = "none";
//     document.getElementById("leaveMessage").textContent = "";

//     if (presentDates[dateStr]) {
//         // Present → Show In/Out
//         document.getElementById("firstIn").textContent = presentDates[dateStr].in || "-";
//         document.getElementById("lastOut").textContent = presentDates[dateStr].out || "-";
//         document.getElementById("dayDetails").style.display = "block";

//     } else if (leaveDates[dateStr] || permissionDates.includes(dateStr)) {
//         // Existing Leave/Permission → Edit + Cancel
//         const currentType = leaveDates[dateStr] || (permissionDates.includes(dateStr) ? "Permission" : "");

//         document.getElementById("leaveForm").innerHTML = `
//             <h3>Manage Leave for <span id="leaveDateDisplay">${new Date(dateStr).toDateString()}</span></h3>
//             <p><strong>Current Status:</strong> <span style="color:#ffff00; font-weight:bold;">${currentType}</span></p>
            
//             <select id="leaveType">
//                 <option value="">Change Type (Optional)</option>
//                 <option value="Pre-planned Leave">Pre-planned Leave</option>
//                 <option value="Emergency Leave">Emergency Leave</option>
//                 <option value="Permission">Permission</option>
//             </select>
            
//             <textarea id="leavePurpose" placeholder="Update purpose (optional)..."></textarea>
            
//             <div style="display:flex; gap:15px; margin-top:20px;">
//                 <button onclick="submitLeave()" style="flex:1; background:#00b1f2; border:none; padding:14px; border-radius:12px; color:white; font-weight:bold;">
//                     UPDATE LEAVE
//                 </button>
//                 <button onclick="cancelLeave('${dateStr}')" style="flex:1; background:#ff4444; border:none; padding:14px; border-radius:12px; color:white; font-weight:bold;">
//                     CANCEL LEAVE
//                 </button>
//             </div>
//             <p id="leaveMessage" style="margin-top:15px;"></p>
//         `;

//         document.getElementById("leaveType").value = currentType;
//         document.getElementById("leaveForm").style.display = "block";

//     } else if (isFuture) {
//         // Future → Apply Form
//         document.getElementById("leaveForm").innerHTML = `
//             <h3>Apply Leave for <span id="leaveDateDisplay">${new Date(dateStr).toDateString()}</span></h3>
//             <select id="leaveType">
//                 <option value="">Select Type</option>
//                 <option value="Pre-planned Leave">Pre-planned Leave</option>
//                 <option value="Emergency Leave">Emergency Leave</option>
//                 <option value="Permission">Permission</option>
//             </select>
//             <textarea id="leavePurpose" placeholder="Purpose of leave..."></textarea>
//             <button onclick="submitLeave()" style="width:100%; margin-top:15px; background:#00b1f2; border:none; padding:16px; border-radius:14px; color:white; font-weight:bold;">
//                 SUBMIT APPLICATION
//             </button>
//             <p id="leaveMessage"></p>
//         `;
//         document.getElementById("leaveForm").style.display = "block";

//     } else {
//         // Absent
//         document.getElementById("firstIn").textContent = "Absent";
//         document.getElementById("lastOut").textContent = "-";
//         document.getElementById("dayDetails").style.display = "block";
//     }
// }

// // === Submit Leave (Apply or Update) ===
// function submitLeave() {
//     const type = document.getElementById("leaveType").value;
//     const purpose = document.getElementById("leavePurpose").value.trim();

//     if (!type) {
//         document.getElementById("leaveMessage").textContent = "Please select a leave type";
//         document.getElementById("leaveMessage").style.color = "#ff6b6b";
//         return;
//     }

//     fetch("/apply-leave", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ date: selectedDate, type, purpose: purpose || "No purpose" })
//     })
//     .then(r => r.json())
//     .then(d => {
//         document.getElementById("leaveMessage").style.color = d.status === "success" ? "#00b1f2" : "#ff6b6b";
//         document.getElementById("leaveMessage").textContent = d.message;

//         if (d.status === "success") {
//             setTimeout(() => {
//                 closeAttendanceCalendar();
//                 openAttendanceCalendar();
//             }, 1500);
//         }
//     });
// }

// // === Cancel Leave ===
// function cancelLeave(dateStr) {
//     if (!confirm("Are you sure you want to CANCEL this leave/permission?\nThis cannot be undone.")) return;

//     fetch("/cancel-leave", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ date: dateStr })
//     })
//     .then(r => r.json())
//     .then(d => {
//         document.getElementById("leaveMessage").style.color = d.status === "success" ? "#00b1f2" : "#ff6b6b";
//         document.getElementById("leaveMessage").textContent = d.message;

//         if (d.status === "success") {
//             setTimeout(() => {
//                 closeAttendanceCalendar();
//                 openAttendanceCalendar();
//             }, 1500);
//         }
//     });
// }

// // === Navigation ===
// function prevMonth() {
//     currentMonth--;
//     if (currentMonth < 0) { currentMonth = 11; currentYear--; }
//     renderCalendar();
// }

// function nextMonth() {
//     currentMonth++;
//     if (currentMonth > 11) { currentMonth = 0; currentYear++; }
//     renderCalendar();
// }

// // === INIT ===
// loadDashboard();
// setInterval(loadDashboard, 60000);


