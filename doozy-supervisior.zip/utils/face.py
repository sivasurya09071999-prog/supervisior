# utils/face.py
import os
import cv2
import numpy as np
import face_recognition
import base64

FACE_DIR = "faces"
os.makedirs(FACE_DIR, exist_ok=True)

def save_face_encoding(username, image_base64):
    try:
        image_data = base64.b64decode(image_base64.split(",")[1])
        np_arr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if img is None:
            return False
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encodings = face_recognition.face_encodings(rgb)
        if len(encodings) == 0:
            return False
        np.save(os.path.join(FACE_DIR, f"{username}.npy"), encodings[0])
        return True
    except Exception as e:
        print(f"Face save error: {e}")
        return False

def match_face(username, image_base64):
    path = os.path.join(FACE_DIR, f"{username}.npy")
    if not os.path.exists(path):
        return False
    try:
        saved = np.load(path)
        image_data = base64.b64decode(image_base64.split(",")[1])
        np_arr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if img is None:
            return False
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encodings = face_recognition.face_encodings(rgb)
        if len(encodings) == 0:
            return False
        return face_recognition.compare_faces([saved], encodings[0], tolerance=0.4)[0]
    except Exception as e:
        print(f"Face match error: {e}")
        return False

        
# # utils/face.py
# import os
# import cv2
# import numpy as np
# import face_recognition
# import base64

# FACE_DIR = "faces"
# os.makedirs(FACE_DIR, exist_ok=True)

# def save_face_encoding(username, image_base64):
#     try:
#         image_data = base64.b64decode(image_base64.split(",")[1])
#         np_arr = np.frombuffer(image_data, np.uint8)
#         img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
#         if img is None: return False
#         rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#         encodings = face_recognition.face_encodings(rgb)
#         if len(encodings) == 0: return False
#         np.save(os.path.join(FACE_DIR, f"{username}.npy"), encodings[0])
#         return True
#     except:
#         return False

# def match_face(username, image_base64):
#     path = os.path.join(FACE_DIR, f"{username}.npy")
#     if not os.path.exists(path): return False
#     saved = np.load(path)
#     try:
#         image_data = base64.b64decode(image_base64.split(",")[1])
#         np_arr = np.frombuffer(image_data, np.uint8)
#         img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
#         if img is None: return False
#         rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#         encodings = face_recognition.face_encodings(rgb)
#         if len(encodings) == 0: return False
#         return face_recognition.compare_faces([saved], encodings[0], tolerance=0.4)[0]
#     except:
#         return False