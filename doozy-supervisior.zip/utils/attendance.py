# utils/attendance.py
from utils.db import get_db_connection

def log_attendance(user_id, action, location=None):
    conn = get_db_connection()
    if not conn:
        return False
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO attendance (user_id, action, location) VALUES (%s, %s, %s)",
            (user_id, action, location)
        )
        conn.commit()
        return True
    except Exception as e:
        print(f"Attendance log error: {e}")
        return False
    finally:
        cursor.close()
        conn.close()
# # utils/attendance.py
# from utils.db import get_db_connection

# def log_attendance(user_id, action):
#     conn = get_db_connection()
#     if not conn:
#         return False
#     cursor = conn.cursor()
#     try:
#         cursor.execute(
#             "INSERT INTO attendance (user_id, action) VALUES (%s, %s)",
#             (user_id, action)
#         )
#         conn.commit()
#         return True
#     except Exception as e:
#         print(f"Attendance log error: {e}")
#         return False
#     finally:
#         cursor.close()
#         conn.close()