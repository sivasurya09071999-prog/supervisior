# utils/db.py
from mysql.connector import Error
import mysql.connector
from config import MYSQL_CONFIG

def get_db_connection():
    try:
        return mysql.connector.connect(**MYSQL_CONFIG)
    except Error as e:
        print(f"Database Connection Error: {e}")
        return None

# # utils/db.py
# from mysql.connector import Error
# import mysql.connector
# from config import MYSQL_CONFIG

# def get_db_connection():
#     try:
#         return mysql.connector.connect(**MYSQL_CONFIG)
#     except Error as e:
#         print(f"DB Error: {e}")
#         return Nones