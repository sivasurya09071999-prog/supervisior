# config.py
MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'office_user',
    'password': 'Doozy@2020',
    'database': 'office_db1',
    'port': 3306
}

OPENAI_API_KEY = 'sk-your-openai-key-here'  # Replace or use env var

# Tamil Nadu Government Holidays 2025 & 2026
TN_HOLIDAYS_2025 = [
    "2025-01-01", "2025-01-15", "2025-01-26",
    "2025-03-31", "2025-04-10", "2025-04-14", "2025-04-18", "2025-05-01",
    "2025-06-07", "2025-07-06", "2025-08-15", "2025-08-16", "2025-08-27",
    "2025-09-05", "2025-10-01", "2025-10-02", "2025-10-20", "2025-12-25"
]

TN_HOLIDAYS_2026 = [
    "2026-01-01", "2026-01-15", "2026-01-16", "2026-01-26",
 "2026-04-14","2026-05-01", "2026-06-26", "2026-08-15", "2026-08-26",
    "2026-10-02", "2026-10-19", "2026-10-20", "2026-12-25"
]

ALL_GOV_HOLIDAYS = TN_HOLIDAYS_2025 + TN_HOLIDAYS_2026

# # config.py
# MYSQL_CONFIG = {
#     'host': 'localhost',
#     'user': 'office_user',
#     'password': 'Doozy@2020',
#     'database': 'office_db',
#     'port': 3306
# }
# OPENAI_API_KEY = "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"  # Put your key here