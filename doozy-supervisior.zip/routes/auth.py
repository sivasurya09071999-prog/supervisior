# routes/auth.py
from flask import Blueprint, request, jsonify, render_template
from flask_login import login_user, logout_user, login_required, current_user
from utils.db import get_db_connection
from utils.face import save_face_encoding, match_face
from utils.attendance import log_attendance
import bcrypt
import os
import re
from mysql.connector import IntegrityError

auth_bp = Blueprint('auth', __name__)

# Strong email validation — accepts doozyrobotics.com, co.in, etc.
email_regex = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')

@auth_bp.route("/")
def index():
    return render_template("login.html")

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    # POST request
    data = request.json
    if not data:
        return jsonify({"status": "fail", "message": "Invalid request data"}), 400

    username = data.get("username", "").strip().lower()
    password = data.get("password", "")
    image = data.get("image", "")
    location = data.get("location", "Unknown Location")

    if not username or not password or not image:
        return jsonify({"status": "fail", "message": "Username, password, and face image are required"}), 400

    conn = get_db_connection()
    if not conn:
        return jsonify({"status": "fail", "message": "Database connection failed"}), 500

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, password_hash, role FROM users WHERE username = %s", (username,))
        row = cursor.fetchone()

        if not row:
            return jsonify({"status": "fail", "message": "Invalid username or password"}), 401

        user_id, db_username, password_hash, role = row

        if not bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8')):
            return jsonify({"status": "fail", "message": "Invalid username or password"}), 401

        if not match_face(db_username, image):
            return jsonify({"status": "denied", "message": "Face not matched"}), 401

        from app import User
        user = User(user_id, db_username, role)
        login_user(user, remember=True)
        
        log_attendance(user_id, "FACE_LOGIN", location)

        return jsonify({"status": "success"})
    
    except Exception as e:
        print(f"Login error: {e}")
        return jsonify({"status": "fail", "message": "An error occurred during login"}), 500
    
    finally:
        if 'cursor' in locals():
            cursor.close()
        if conn:
            conn.close()

@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "GET":
        return render_template("forgot_password.html")
    
    data = request.json
    email = data.get("email", "").strip().lower()

    if not email or not email_regex.match(email):
        return jsonify({"status": "error", "message": "Valid email is required"})

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM users WHERE email = %s", (email,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()

    if row:
        print(f"[SIMULATED] Password reset link sent to {email}")
        return jsonify({"status": "success", "message": "Password reset link sent to your email"})
    else:
        return jsonify({"status": "error", "message": "Email not found"})



@auth_bp.route("/register-with-face", methods=["POST"])
def register_with_face():
    data = request.json
    username = data["username"].strip().lower()
    email = data.get("email", "").strip().lower()
    password = data["password"]
    role = data["role"]
    image = data["image"]
    location = data.get("location", "Unknown Location")

    # Validate email
    if not email or not email_regex.match(email):
        return jsonify({"status": "error", "message": "Valid email is required"})

    if not save_face_encoding(username, image):
        return jsonify({"status": "error", "message": "Face not detected"})

    password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    conn = get_db_connection()
    if not conn:
        face_path = os.path.join("faces", f"{username}.npy")
        if os.path.exists(face_path):
            os.remove(face_path)
        return jsonify({"status": "error", "message": "Database error"})

    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO users (username, password_hash, role, email) 
            VALUES (%s, %s, %s, %s)
        """, (username, password_hash, role, email))
        conn.commit()

        cursor.execute("SELECT id, username, role FROM users WHERE username = %s", (username,))
        row = cursor.fetchone()
        user_id, _, user_role = row

        from app import User
        user = User(user_id, username, user_role)
        login_user(user, remember=True)
        
        log_attendance(user_id, "REGISTERED_WITH_FACE", location)

        return jsonify({"status": "success"})
    
    except IntegrityError:
        face_path = os.path.join("faces", f"{username}.npy")
        if os.path.exists(face_path):
            os.remove(face_path)
        return jsonify({"status": "error", "message": "Username or email already exists"})
    
    finally:
        cursor.close()
        conn.close()

@auth_bp.route("/logout")
@login_required
def logout():
    log_attendance(current_user.id, "LOGOUT")
    logout_user()
    return jsonify({"status": "logged_out"})

# # routes/auth.py
# from flask import Blueprint, request, jsonify, render_template
# from flask_login import login_user, logout_user, login_required, current_user
# from utils.db import get_db_connection
# from utils.face import save_face_encoding, match_face
# from utils.attendance import log_attendance
# import bcrypt
# import os
# from mysql.connector import IntegrityError

# auth_bp = Blueprint('auth', __name__)

# @auth_bp.route("/")
# def index():
#     return render_template("login.html")

# @auth_bp.route("/login", methods=["GET", "POST"])
# def login():
#     if request.method == "GET":
#         return render_template("login.html")

#     data = request.json
#     username = data["username"].strip().lower()
#     password = data["password"]
#     image = data["image"]
#     location = data.get("location", "Unknown Location")  # From frontend

#     conn = get_db_connection()
#     if not conn:
#         return jsonify({"status": "fail", "message": "Database error"})

#     cursor = conn.cursor()
#     cursor.execute("SELECT id, username, password_hash, role FROM users WHERE username = %s", (username,))
#     row = cursor.fetchone()

#     if not row:
#         cursor.close()
#         conn.close()
#         return jsonify({"status": "fail", "message": "Invalid username or password"})

#     user_id, db_username, password_hash, role = row

#     if not bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8')):
#         cursor.close()
#         conn.close()
#         return jsonify({"status": "fail", "message": "Invalid username or password"})

#     if not match_face(db_username, image):
#         cursor.close()
#         conn.close()
#         return jsonify({"status": "denied", "message": "Face not matched"})

#     from app import User
#     user = User(user_id, db_username, role)
#     login_user(user, remember=True)
    
#     # Log attendance with location
#     log_attendance(user_id, "FACE_LOGIN", location)

#     cursor.close()
#     conn.close()
#     return jsonify({"status": "success"})

# @auth_bp.route("/forgot-password", methods=["GET", "POST"])
# def forgot_password():
#     if request.method == "GET":
#         return render_template("forgot_password.html")
    
#     data = request.json
#     email = data.get("email", "").strip().lower()

#     if not email:
#         return jsonify({"status": "error", "message": "Email is required"})

#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT username FROM users WHERE email = %s", (email,))
#     row = cursor.fetchone()
#     cursor.close()
#     conn.close()

#     if row:
#         username = row[0]
#         # In real app: send email with reset link
#         # For demo: just return success
#         print(f"[SIMULATED EMAIL] Password reset link sent to {email} for user {username}")
#         return jsonify({"status": "success", "message": "Reset link sent to your email"})
#     else:
#         return jsonify({"status": "error", "message": "Email not found"})

# @auth_bp.route("/reset-password/<token>", methods=["GET", "POST"])
# def reset_password(token):
#     # In real app: validate token
#     # For demo: simple form
#     if request.method == "GET":
#         return render_template("reset_password.html", token=token)
    
#     # Handle password update (simplified)
#     return jsonify({"status": "success", "message": "Password reset successful (demo)"})
    
# @auth_bp.route("/register-with-face", methods=["POST"])
# def register_with_face():
#     data = request.json
#     username = data["username"].strip().lower()
#     password = data["password"]
#     role = data["role"]
#     email = data.get("email", "").strip().lower()  # New email field
#     image = data["image"]
#     location = data.get("location", "Unknown Location")

#     if not email or "@" not in email:
#         return jsonify({"status": "error", "message": "Valid email is required"})

#     if not save_face_encoding(username, image):
#         return jsonify({"status": "error", "message": "Face not detected"})

#     password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

#     conn = get_db_connection()
#     if not conn:
#         face_path = os.path.join("faces", f"{username}.npy")
#         if os.path.exists(face_path):
#             os.remove(face_path)
#         return jsonify({"status": "error", "message": "Database error"})

#     cursor = conn.cursor()
#     try:
#         cursor.execute("""
#             INSERT INTO users (username, password_hash, role, email) 
#             VALUES (%s, %s, %s, %s)
#         """, (username, password_hash, role, email))
#         conn.commit()

#         # ... rest same (login user, log attendance)
#         return jsonify({"status": "success"})
    
#     except IntegrityError as e:
#         # Handle duplicate username or email
#         face_path = os.path.join("faces", f"{username}.npy")
#         if os.path.exists(face_path):
#             os.remove(face_path)
#         if "username" in str(e):
#             return jsonify({"status": "error", "message": "Username already exists"})
#         elif "email" in str(e):
#             return jsonify({"status": "error", "message": "Email already registered"})
#         return jsonify({"status": "error", "message": "Registration failed"})
    
#     finally:
#         cursor.close()
#         conn.close()


# @auth_bp.route("/logout")
# @login_required
# def logout():
#     # Optional: log logout with location (if you want to capture it again)
#     log_attendance(current_user.id, "LOGOUT")
#     logout_user()
#     return jsonify({"status": "logged_out"})



# # routes/auth.py
# from flask import Blueprint, request, jsonify, render_template
# from flask_login import login_user, logout_user, login_required, current_user
# from utils.db import get_db_connection
# from utils.face import save_face_encoding, match_face
# from utils.attendance import log_attendance
# import bcrypt
# import os
# from mysql.connector import IntegrityError

# auth_bp = Blueprint('auth', __name__)

# @auth_bp.route("/")
# def index():
#     return render_template("login.html")

# @auth_bp.route("/login", methods=["GET", "POST"])
# def login():
#     if request.method == "GET":
#         return render_template("login.html")

#     data = request.json
#     username = data["username"].strip().lower()
#     password = data["password"]
#     image = data["image"]

#     conn = get_db_connection()
#     if not conn:
#         return jsonify({"status": "fail", "message": "Database error"})

#     cursor = conn.cursor()
#     cursor.execute("SELECT id, username, password_hash, role FROM users WHERE username = %s", (username,))
#     row = cursor.fetchone()

#     if not row:
#         cursor.close()
#         conn.close()
#         return jsonify({"status": "fail", "message": "Invalid username or password"})

#     user_id, db_username, password_hash, role = row

#     if not bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8')):
#         cursor.close()
#         conn.close()
#         return jsonify({"status": "fail", "message": "Invalid username or password"})

#     if not match_face(db_username, image):
#         cursor.close()
#         conn.close()
#         return jsonify({"status": "denied", "message": "Face not matched"})

#     from app import User
#     user = User(user_id, db_username, role)
#     login_user(user, remember=True)
#     log_attendance(user_id, "FACE_LOGIN")

#     cursor.close()
#     conn.close()
#     return jsonify({"status": "success"})

# @auth_bp.route("/register-with-face", methods=["POST"])
# def register_with_face():
#     data = request.json
#     username = data["username"].strip().lower()
#     password = data["password"]
#     role = data["role"]
#     image = data["image"]

#     if not save_face_encoding(username, image):
#         return jsonify({"status": "error", "message": "Face not detected"})

#     password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

#     conn = get_db_connection()
#     if not conn:
#         face_path = os.path.join("faces", f"{username}.npy")
#         if os.path.exists(face_path):
#             os.remove(face_path)
#         return jsonify({"status": "error", "message": "Database error"})

#     cursor = conn.cursor()
#     try:
#         cursor.execute("INSERT INTO users (username, password_hash, role) VALUES (%s, %s, %s)", (username, password_hash, role))
#         conn.commit()

#         cursor.execute("SELECT id, username, role FROM users WHERE username = %s", (username,))
#         row = cursor.fetchone()
#         user_id, _, user_role = row

#         from app import User
#         user = User(user_id, username, user_role)
#         login_user(user, remember=True)
#         log_attendance(user_id, "REGISTERED_WITH_FACE")

#         return jsonify({"status": "success"})
#     except IntegrityError:
#         face_path = os.path.join("faces", f"{username}.npy")
#         if os.path.exists(face_path):
#             os.remove(face_path)
#         return jsonify({"status": "error", "message": "Username already exists"})
#     finally:
#         cursor.close()
#         conn.close()

# @auth_bp.route("/logout")
# @login_required
# def logout():
#     log_attendance(current_user.id, "LOGOUT")
#     logout_user()
#     return jsonify({"status": "logged_out"})

# # routes/auth.py
# from flask import Blueprint, request, jsonify, render_template
# from flask_login import login_user, logout_user, login_required, current_user
# from utils.db import get_db_connection
# from utils.face import save_face_encoding, match_face
# from utils.attendance import log_attendance  # we'll define later
# import bcrypt

# auth_bp = Blueprint('auth', __name__)

# @auth_bp.route("/")
# def index():
#     return render_template("login.html")

# @auth_bp.route("/login", methods=["GET", "POST"])
# def login():
#     if request.method == "GET":
#         return render_template("login.html")
    
#     data = request.json
#     username = data["username"].strip()
#     password = data["password"]
#     image = data["image"]

#     conn = get_db_connection()
#     if not conn: return jsonify({"status": "fail", "message": "DB error"})
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT id, username, password_hash, role FROM users WHERE username = %s", (username,))
#     row = cursor.fetchone()
#     cursor.close()
#     conn.close()

#     if row and bcrypt.checkpw(password.encode(), row[2].encode()):
#         if match_face(username, image):
#             from app import User  # Import here to avoid circular
#             user = User(row[0], row[1], row[3])
#             login_user(user, remember=True)
#             log_attendance(username, "FACE_LOGIN")
#             return jsonify({"status": "success"})
#         else:
#             return jsonify({"status": "denied", "message": "Face not matched"})
#     return jsonify({"status": "fail", "message": "Invalid username or password"})

# @auth_bp.route("/register-with-face", methods=["POST"])
# def register_with_face():
#     data = request.json
#     username = data["username"].strip()
#     password = data["password"]
#     role = data["role"]
#     image = data["image"]

#     if not save_face_encoding(username, image):
#         return jsonify({"status": "error", "message": "Face not detected"})

#     password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

#     conn = get_db_connection()
#     cursor = conn.cursor()
#     try:
#         cursor.execute("INSERT INTO users (username, password_hash, role) VALUES (%s, %s, %s)", (username, password_hash, role))
#         conn.commit()
#         cursor.execute("SELECT id, username, role FROM users WHERE username = %s", (username,))
#         row = cursor.fetchone()
#         from app import User
#         user = User(row[0], row[1], row[2])
#         login_user(user, remember=True)
#         log_attendance(username, "REGISTERED_WITH_FACE")
#         return jsonify({"status": "success"})
#     except mysql.connector.IntegrityError:
#         os.remove(os.path.join("faces", f"{username}.npy"))
#         return jsonify({"status": "error", "message": "Username already exists"})
#     finally:
#         cursor.close()
#         conn.close()

# @auth_bp.route("/logout")
# @login_required
# def logout():
#     log_attendance(current_user.username, "LOGOUT")
#     logout_user()
#     return jsonify({"status": "logged_out"})