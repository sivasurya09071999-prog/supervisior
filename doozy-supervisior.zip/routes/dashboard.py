# routes/dashboard.py
from flask import Blueprint, render_template, jsonify, request
from flask_login import login_required, current_user
from utils.db import get_db_connection
from datetime import date, timedelta, datetime

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")

@dashboard_bp.route("/dashboard-data")
@login_required
def dashboard_data():
    user_id = current_user.id
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Last 6 Days Attendance
    attendance_days = []
    for i in range(6):
        day_date = date.today() - timedelta(days=i)
        day_str = day_date.strftime("%Y-%m-%d")
        
        cursor.execute("""
            SELECT action, `timestamp`
            FROM attendance
            WHERE user_id = %s AND DATE(`timestamp`) = %s
            ORDER BY `timestamp` ASC
        """, (user_id, day_str))
        logs = cursor.fetchall()

        first_in = None
        last_out = None
        hours = "0h 0m"

        if logs:
            for log in logs:
                if ("LOGIN" in log["action"] or "REGISTERED" in log["action"]) and not first_in:
                    first_in = log["timestamp"].strftime("%H:%M")
            for log in reversed(logs):
                if log["action"] == "LOGOUT":
                    last_out = log["timestamp"].strftime("%H:%M")
                    break
            
            if first_in and last_out:
                in_time = datetime.strptime(first_in, "%H:%M")
                out_time = datetime.strptime(last_out, "%H:%M")
                diff = out_time - in_time
                if diff.total_seconds() < 0:
                    diff += timedelta(days=1)
                total_mins = int(diff.total_seconds() // 60)
                hours = f"{total_mins // 60}h {total_mins % 60}m"

        attendance_days.append({
            "date": day_date.strftime("%a, %b %d"),
            "first_in": first_in or "-",
            "last_out": last_out or "-",
            "hours": hours
        })

    # Latest Task
    cursor.execute("""
        SELECT task, progress, date
        FROM tasks
        WHERE user_id = %s
        ORDER BY date DESC, created_at DESC
        LIMIT 1
    """, (user_id,))
    latest_task = cursor.fetchone()

    today_str = date.today().strftime("%Y-%m-%d")

    if latest_task:
        task_progress = latest_task["progress"]
        task_date_str = latest_task["date"].strftime("%Y-%m-%d")
        if task_date_str == today_str:
            task_name_display = latest_task["task"]
        else:
            last_updated = latest_task["date"].strftime("%b %d")
            task_name_display = f"{latest_task['task']} (Last updated: {last_updated})"
    else:
        task_name_display = "No task assigned yet"
        task_progress = "0"

    cursor.close()
    conn.close()

    return jsonify({
        "username": current_user.username,
        "role": current_user.role,
        "task_name": task_name_display,
        "task_progress": task_progress,
        "attendance": attendance_days[::-1]
    })

@dashboard_bp.route("/task", methods=["POST"])
@login_required
def task():
    data = request.json
    task_name = data["task"].strip()
    progress = data["progress"]

    if not task_name:
        return jsonify({"status": "error", "message": "Task description is required"})

    if not progress.endswith("%"):
        progress += "%"

    conn = get_db_connection()
    cursor = conn.cursor()
    today = date.today().strftime("%Y-%m-%d")

    cursor.execute("""
        INSERT INTO tasks (user_id, task, progress, date)
        VALUES (%s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE task = %s, progress = %s
    """, (current_user.id, task_name, progress, today, task_name, progress))
    
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({"status": "saved", "message": "Task updated successfully!"})
# # routes/dashboard.py
# from flask import Blueprint, render_template, jsonify, request
# from flask_login import login_required, current_user
# from utils.db import get_db_connection
# from datetime import date, timedelta, datetime

# dashboard_bp = Blueprint('dashboard', __name__)

# @dashboard_bp.route("/dashboard")
# @login_required
# def dashboard():
#     return render_template("dashboard.html")

# @dashboard_bp.route("/dashboard-data")
# @login_required
# def dashboard_data():
#     username = current_user.username
#     conn = get_db_connection()
#     cursor = conn.cursor(dictionary=True)

#     # === Last 6 Days Attendance (unchanged) ===
#     attendance_days = []
#     for i in range(6):
#         day_date = date.today() - timedelta(days=i)
#         day_str = day_date.strftime("%Y-%m-%d")
#         cursor.execute("""
#             SELECT action, timestamp FROM attendance 
#             WHERE username = %s AND DATE(timestamp) = %s 
#             ORDER BY timestamp ASC
#         """, (username, day_str))
#         logs = cursor.fetchall()

#         first_in = None
#         last_out = None
#         hours = "0h 0m"

#         if logs:
#             for log in logs:
#                 if ("LOGIN" in log["action"] or "REGISTERED" in log["action"]) and not first_in:
#                     first_in = log["timestamp"].strftime("%H:%M")
#             for log in reversed(logs):
#                 if log["action"] == "LOGOUT":
#                     last_out = log["timestamp"].strftime("%H:%M")
#                     break
#             if first_in and last_out:
#                 in_time = datetime.strptime(first_in, "%H:%M")
#                 out_time = datetime.strptime(last_out, "%H:%M")
#                 diff = out_time - in_time
#                 if diff.total_seconds() < 0:
#                     diff += timedelta(days=1)
#                 total_mins = int(diff.total_seconds() // 60)
#                 hours = f"{total_mins // 60}h {total_mins % 60}m"

#         attendance_days.append({
#             "date": day_date.strftime("%a, %b %d"),
#             "first_in": first_in or "-",
#             "last_out": last_out or "-",
#             "hours": hours
#         })

#     # === Latest Task (Most Recent - Even if Not Today) ===
#     cursor.execute("""
#         SELECT task, progress, date 
#         FROM tasks 
#         WHERE username = %s 
#         ORDER BY date DESC, created_at DESC 
#         LIMIT 1
#     """, (username,))
#     latest_task = cursor.fetchone()

#     today_str = date.today().strftime("%Y-%m-%d")

#     if latest_task:
#         task_progress = latest_task["progress"]  # e.g., "10" or "10%"
#         task_date_str = latest_task["date"].strftime("%Y-%m-%d")

#         if task_date_str == today_str:
#             # Task is from today
#             task_name_display = latest_task["task"]
#         else:
#             # Task is from previous day(s)
#             last_updated = latest_task["date"].strftime("%b %d")  # e.g., "Dec 30"
#             task_name_display = f"{latest_task['task']} (Last updated: {last_updated})"
#     else:
#         # No task ever recorded
#         task_name_display = "No task assigned yet"
#         task_progress = "0"

#     cursor.close()
#     conn.close()

#     return jsonify({
#         "username": username,
#         "role": current_user.role,
#         "task_name": task_name_display,      # Shown in taskNameDisplay
#         "task_progress": task_progress,      # Used for chart (e.g., "10")
#         "attendance": attendance_days[::-1]  # Most recent day first
#     })

# @dashboard_bp.route("/task", methods=["POST"])
# @login_required
# def task():
#     data = request.json
#     task_name = data["task"].strip()
#     progress = data["progress"]  # Expected like "10%" or "10"

#     if not task_name:
#         return jsonify({"status": "error", "message": "Task description is required"})

#     # Ensure progress ends with %
#     if not progress.endswith("%"):
#         progress = progress + "%"

#     conn = get_db_connection()
#     cursor = conn.cursor()
#     today = date.today().strftime("%Y-%m-%d")

#     cursor.execute("""
#         INSERT INTO tasks (username, task, progress, date) 
#         VALUES (%s, %s, %s, %s) 
#         ON DUPLICATE KEY UPDATE task = %s, progress = %s
#     """, (current_user.username, task_name, progress, today, task_name, progress))
#     conn.commit()
#     cursor.close()
#     conn.close()

#     return jsonify({"status": "saved", "message": "Task updated successfully!"})
# # routes/dashboard.py
# from flask import Blueprint, render_template, jsonify
# from flask_login import login_required, current_user
# from utils.db import get_db_connection
# from datetime import date, timedelta, datetime
# dashboard_bp = Blueprint('dashboard', __name__)

# @dashboard_bp.route("/dashboard")
# @login_required
# def dashboard():
#     return render_template("dashboard.html")

# @dashboard_bp.route("/dashboard-data")
# @login_required
# def dashboard_data():
#     username = current_user.username
#     conn = get_db_connection()
#     cursor = conn.cursor(dictionary=True)

#     # Last 6 days attendance
#     attendance_days = []
#     for i in range(6):
#         day_date = date.today() - timedelta(days=i)
#         day_str = day_date.strftime("%Y-%m-%d")
#         cursor.execute("""
#             SELECT action, timestamp FROM attendance 
#             WHERE username = %s AND DATE(timestamp) = %s 
#             ORDER BY timestamp ASC
#         """, (username, day_str))
#         logs = cursor.fetchall()

#         first_in = None
#         last_out = None
#         hours = "0h 0m"

#         if logs:
#             for log in logs:
#                 if ("LOGIN" in log["action"] or "REGISTERED" in log["action"]) and not first_in:
#                     first_in = log["timestamp"].strftime("%H:%M")
#             for log in reversed(logs):
#                 if log["action"] == "LOGOUT":
#                     last_out = log["timestamp"].strftime("%H:%M")
#                     break
#             if first_in and last_out:
#                 in_time = datetime.strptime(first_in, "%H:%M")
#                 out_time = datetime.strptime(last_out, "%H:%M")
#                 diff = out_time - in_time
#                 if diff.total_seconds() < 0:
#                     diff += timedelta(days=1)
#                 total_mins = int(diff.total_seconds() // 60)
#                 hours = f"{total_mins // 60}h {total_mins % 60}m"

#         attendance_days.append({
#             "date": day_date.strftime("%a, %b %d"),
#             "first_in": first_in or "-",
#             "last_out": last_out or "-",
#             "hours": hours
#         })

#     # Today's task
#     today = date.today().strftime("%Y-%m-%d")
#     cursor.execute("SELECT task, progress FROM tasks WHERE username = %s AND date = %s", (username, today))
#     task_row = cursor.fetchone()
#     task_name = task_row["task"] if task_row else "No task today"
#     task_progress = task_row["progress"] if task_row else "0"

#     cursor.close()
#     conn.close()

#     return jsonify({
#         "username": username,
#         "role": current_user.role,
#         "task_name": task_name,
#         "task_progress": task_progress,
#         "attendance": attendance_days[::-1]
#     })

# @dashboard_bp.route("/task", methods=["POST"])
# @login_required
# def task():
#     data = request.json
#     task_name = data["task"]
#     progress = data["progress"]
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     today = date.today().strftime("%Y-%m-%d")
#     cursor.execute("""
#         INSERT INTO tasks (username, task, progress, date) 
#         VALUES (%s, %s, %s, %s) 
#         ON DUPLICATE KEY UPDATE task = %s, progress = %s
#     """, (current_user.username, task_name, progress, today, task_name, progress))
#     conn.commit()
#     cursor.close()
#     conn.close()
#     return jsonify({"status": "saved"})