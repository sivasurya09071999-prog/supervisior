# routes/attendance.py
from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from utils.db import get_db_connection
from config import ALL_GOV_HOLIDAYS
import openai
from config import OPENAI_API_KEY
from datetime import date, timedelta
openai.api_key = OPENAI_API_KEY
attendance_bp = Blueprint('attendance', __name__)

@attendance_bp.route("/attendance-calendar-data")
@login_required
def attendance_calendar_data():
    user_id = current_user.id
    conn = get_db_connection()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500

    cursor = conn.cursor(dictionary=True)

    # Present Dates (First In / Last Out)
    cursor.execute("""
        SELECT 
            DATE(`timestamp`) as date,
            MIN(`timestamp`) as first_in,
            MAX(`timestamp`) as last_out
        FROM attendance
        WHERE user_id = %s 
          AND (action LIKE '%LOGIN%' OR action LIKE '%REGISTERED%')
        GROUP BY DATE(`timestamp`)
    """, (user_id,))
    attendance_rows = cursor.fetchall()

    present_dates = {
        row["date"].strftime("%Y-%m-%d"): {
            "in": row["first_in"].strftime("%H:%M"),
            "out": row["last_out"].strftime("%H:%M")
        }
        for row in attendance_rows
    }

    # Leave Applications
    cursor.execute("""
        SELECT leave_date, leave_type, status
        FROM leave_applications
        WHERE user_id = %s
    """, (user_id,))
    leave_rows = cursor.fetchall()

    leave_dates = {}
    permission_dates = set()
    for row in leave_rows:
        d = row["leave_date"].strftime("%Y-%m-%d")
        if row["status"] in ["Approved", "Pending"]:
            if row["leave_type"] in ["Pre-planned Leave", "Emergency Leave"]:
                leave_dates[d] = row["leave_type"]
            elif row["leave_type"] == "Permission":
                permission_dates.add(d)

    # === Professional Summary: Only Completed Days Up to Today ===
    today = date.today()
    year = today.year
    month = today.month

    # First day of month
    first_day = date(year, month, 1)

    # Count working days from first_day to today (inclusive)
    working_days_so_far = 0
    current = first_day
    while current <= today:
        date_str = current.strftime("%Y-%m-%d")
        # Exclude Sundays and government holidays
        if current.weekday() != 6 and date_str not in ALL_GOV_HOLIDAYS:
            working_days_so_far += 1
        current += timedelta(days=1)

    # Count present and leave up to today
    present_count = sum(1 for d in present_dates if date.fromisoformat(d) <= today)
    leave_count = sum(1 for d in leave_dates if date.fromisoformat(d) <= today) + \
                  len([d for d in permission_dates if date.fromisoformat(d) <= today])

    absent_count = working_days_so_far - present_count - leave_count

    # Salary reduction: Only actual leave taken so far
    daily_rate = 1000  # Change to your actual daily salary
    unpaid_days = leave_count
    salary_reduction = unpaid_days * daily_rate

    cursor.close()
    conn.close()

    return jsonify({
        "present_dates": present_dates,
        "leave_dates": leave_dates,
        "permission_dates": list(permission_dates),
        "gov_holidays": ALL_GOV_HOLIDAYS,
        "month_summary": {
            "working_days_so_far": working_days_so_far,
            "present": present_count,
            "leave": leave_count,
            "absent": absent_count,
            "unpaid_days": unpaid_days,
            "salary_reduction": salary_reduction,
            "month_name": today.strftime("%B %Y"),
            "as_of": today.strftime("%B %d, %Y")
        }
    })

@attendance_bp.route("/apply-leave", methods=["POST"])
@login_required
def apply_leave():
    data = request.json
    leave_date = data.get("date")
    leave_type = data.get("type")
    purpose = data.get("purpose", "").strip()

    if not purpose:
        return jsonify({"status": "error", "message": "Purpose is required"}), 400

    conn = get_db_connection()
    if not conn:
        return jsonify({"status": "error", "message": "Database error"}), 500

    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO leave_applications 
                (user_id, leave_date, leave_type, purpose)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                purpose = VALUES(purpose),
                leave_type = VALUES(leave_type),
                status = 'Pending'
        """, (current_user.id, leave_date, leave_type, purpose))
        conn.commit()
        return jsonify({"status": "success", "message": "Leave applied successfully!"})
    except Exception as e:
        print(f"Apply leave error: {e}")
        return jsonify({"status": "error", "message": "Failed to apply leave"}), 500
    finally:
        cursor.close()
        conn.close()

@attendance_bp.route("/cancel-leave", methods=["POST"])
@login_required
def cancel_leave():
    data = request.json
    leave_date = data.get("date")

    conn = get_db_connection()
    if not conn:
        return jsonify({"status": "error", "message": "Database error"}), 500

    cursor = conn.cursor()
    try:
        cursor.execute("""
            DELETE FROM leave_applications
            WHERE user_id = %s AND leave_date = %s
        """, (current_user.id, leave_date))
        conn.commit()
        if cursor.rowcount > 0:
            return jsonify({"status": "success", "message": "Leave cancelled successfully!"})
        else:
            return jsonify({"status": "error", "message": "No leave found to cancel"})
    except Exception as e:
        print(f"Cancel leave error: {e}")
        return jsonify({"status": "error", "message": "Failed to cancel leave"}), 500
    finally:
        cursor.close()
        conn.close()

@attendance_bp.route("/ask-ai", methods=["POST"])
@login_required
def ask_ai():
    question = request.json.get("question", "").strip()
    if not question:
        return jsonify({"answer": "Please ask a question."})

    user_id = current_user.id
    conn = get_db_connection()
    if not conn:
        return jsonify({"answer": "Database unavailable."})

    cursor = conn.cursor()

    cursor.execute("""
        SELECT action, `timestamp`
        FROM attendance
        WHERE user_id = %s
        ORDER BY `timestamp` DESC
        LIMIT 20
    """, (user_id,))
    attendance_records = cursor.fetchall()

    cursor.execute("""
        SELECT task, progress, date
        FROM tasks
        WHERE user_id = %s
        ORDER BY date DESC, created_at DESC
        LIMIT 20
    """, (user_id,))
    task_records = cursor.fetchall()

    cursor.close()
    conn.close()

    att_context = "\n".join([f"{r[0]} at {r[1]}" for r in attendance_records])
    task_context = "\n".join([f"{r[0]} ({r[1]}) on {r[2]}" for r in task_records])
    context = f"Recent Attendance:\n{att_context}\n\nRecent Tasks:\n{task_context}"

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are Doozy HR Assistant. Answer professionally."},
                {"role": "user", "content": f"Data:\n{context}\n\nQuestion: {question}"}
            ],
            temperature=0.7
        )
        answer = response.choices[0].message.content.strip()
    except Exception as e:
        print(f"OpenAI error: {e}")
        answer = "HR Assistant unavailable."

    return jsonify({"answer": answer})

# # routes/attendance.py
# from flask import Blueprint, jsonify, request
# from flask_login import login_required, current_user
# from utils.db import get_db_connection
# from config import ALL_GOV_HOLIDAYS
# import openai
# from config import OPENAI_API_KEY

# openai.api_key = OPENAI_API_KEY

# attendance_bp = Blueprint('attendance', __name__)

# @attendance_bp.route("/attendance-calendar-data")

# @login_required
# def attendance_calendar_data():
#     user_id = current_user.id
#     conn = get_db_connection()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500

#     cursor = conn.cursor(dictionary=True)

#     # Get present dates
#     cursor.execute("""
#         SELECT 
#             DATE(`timestamp`) as date,
#             MIN(`timestamp`) as first_in,
#             MAX(`timestamp`) as last_out
#         FROM attendance
#         WHERE user_id = %s 
#           AND (action LIKE '%LOGIN%' OR action LIKE '%REGISTERED%')
#         GROUP BY DATE(`timestamp`)
#     """, (user_id,))
#     attendance_rows = cursor.fetchall()

#     present_dates = {
#         row["date"].strftime("%Y-%m-%d"): {
#             "in": row["first_in"].strftime("%H:%M"),
#             "out": row["last_out"].strftime("%H:%M")
#         }
#         for row in attendance_rows
#     }

#     # Get leave applications
#     cursor.execute("""
#         SELECT leave_date, leave_type, status
#         FROM leave_applications
#         WHERE user_id = %s
#     """, (user_id,))
#     leave_rows = cursor.fetchall()

#     leave_dates = {}
#     permission_dates = set()
#     for row in leave_rows:
#         d = row["leave_date"].strftime("%Y-%m-%d")
#         if row["status"] in ["Approved", "Pending"]:
#             if row["leave_type"] in ["Pre-planned Leave", "Emergency Leave"]:
#                 leave_dates[d] = row["leave_type"]
#             elif row["leave_type"] == "Permission":
#                 permission_dates.add(d)

#     cursor.close()
#     conn.close()

#     return jsonify({
#         "present_dates": present_dates,
#         "leave_dates": leave_dates,
#         "permission_dates": list(permission_dates),
#         "gov_holidays": ALL_GOV_HOLIDAYS
#     })
# @login_required
# def attendance_calendar_data():
#     user_id = current_user.id
#     conn = get_db_connection()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500

#     cursor = conn.cursor(dictionary=True)

#     cursor.execute("""
#         SELECT 
#             DATE(`timestamp`) as date,
#             MIN(`timestamp`) as first_in,
#             MAX(`timestamp`) as last_out
#         FROM attendance
#         WHERE user_id = %s 
#           AND (action LIKE '%LOGIN%' OR action LIKE '%REGISTERED%')
#         GROUP BY DATE(`timestamp`)
#     """, (user_id,))
#     attendance_rows = cursor.fetchall()

#     present_dates = {
#         row["date"].strftime("%Y-%m-%d"): {
#             "in": row["first_in"].strftime("%H:%M"),
#             "out": row["last_out"].strftime("%H:%M")
#         }
#         for row in attendance_rows
#     }

#     cursor.execute("""
#         SELECT leave_date, leave_type, status
#         FROM leave_applications
#         WHERE user_id = %s
#     """, (user_id,))
#     leave_rows = cursor.fetchall()

#     leave_dates = {}
#     permission_dates = set()
#     for row in leave_rows:
#         d = row["leave_date"].strftime("%Y-%m-%d")
#         if row["status"] in ["Approved", "Pending"]:
#             if row["leave_type"] in ["Pre-planned Leave", "Emergency Leave"]:
#                 leave_dates[d] = row["leave_type"]
#             elif row["leave_type"] == "Permission":
#                 permission_dates.add(d)

#     cursor.close()
#     conn.close()

#     return jsonify({
#         "present_dates": present_dates,
#         "leave_dates": leave_dates,
#         "permission_dates": list(permission_dates),
#         "gov_holidays": ALL_GOV_HOLIDAYS
#     })

# @attendance_bp.route("/apply-leave", methods=["POST"])
# @login_required
# def apply_leave():
#     data = request.json
#     leave_date = data.get("date")
#     leave_type = data.get("type")
#     purpose = data.get("purpose", "").strip()

#     if not purpose:
#         return jsonify({"status": "error", "message": "Purpose is required"}), 400

#     conn = get_db_connection()
#     if not conn:
#         return jsonify({"status": "error", "message": "Database error"}), 500

#     cursor = conn.cursor()
#     try:
#         cursor.execute("""
#             INSERT INTO leave_applications 
#                 (user_id, leave_date, leave_type, purpose)
#             VALUES (%s, %s, %s, %s)
#             ON DUPLICATE KEY UPDATE
#                 purpose = VALUES(purpose),
#                 leave_type = VALUES(leave_type),
#                 status = 'Pending'
#         """, (current_user.id, leave_date, leave_type, purpose))
#         conn.commit()
#         return jsonify({"status": "success", "message": "Leave applied successfully!"})
#     except Exception as e:
#         print(f"Apply leave error: {e}")
#         return jsonify({"status": "error", "message": "Failed to apply leave"}), 500
#     finally:
#         cursor.close()
#         conn.close()

# @attendance_bp.route("/cancel-leave", methods=["POST"])
# @login_required
# def cancel_leave():
#     data = request.json
#     leave_date = data.get("date")

#     conn = get_db_connection()
#     if not conn:
#         return jsonify({"status": "error", "message": "Database error"}), 500

#     cursor = conn.cursor()
#     try:
#         cursor.execute("""
#             DELETE FROM leave_applications
#             WHERE user_id = %s AND leave_date = %s
#         """, (current_user.id, leave_date))
#         conn.commit()
#         if cursor.rowcount > 0:
#             return jsonify({"status": "success", "message": "Leave cancelled successfully!"})
#         else:
#             return jsonify({"status": "error", "message": "No leave found to cancel"})
#     except Exception as e:
#         print(f"Cancel leave error: {e}")
#         return jsonify({"status": "error", "message": "Failed to cancel leave"}), 500
#     finally:
#         cursor.close()
#         conn.close()


# @attendance_bp.route("/ask-ai", methods=["POST"])
# @login_required
# def ask_ai():
#     question = request.json.get("question", "").strip()
#     if not question:
#         return jsonify({"answer": "Please ask a question."})

#     user_id = current_user.id
#     conn = get_db_connection()
#     if not conn:
#         return jsonify({"answer": "Database unavailable."})

#     cursor = conn.cursor()

#     cursor.execute("""
#         SELECT action, `timestamp`
#         FROM attendance
#         WHERE user_id = %s
#         ORDER BY `timestamp` DESC
#         LIMIT 20
#     """, (user_id,))
#     attendance_records = cursor.fetchall()

#     cursor.execute("""
#         SELECT task, progress, date
#         FROM tasks
#         WHERE user_id = %s
#         ORDER BY date DESC, created_at DESC
#         LIMIT 20
#     """, (user_id,))
#     task_records = cursor.fetchall()

#     cursor.close()
#     conn.close()

#     att_context = "\n".join([f"{r[0]} at {r[1]}" for r in attendance_records])
#     task_context = "\n".join([f"{r[0]} ({r[1]}) on {r[2]}" for r in task_records])
#     context = f"Recent Attendance:\n{att_context}\n\nRecent Tasks:\n{task_context}"

#     try:
#         response = openai.ChatCompletion.create(
#             model="gpt-4o-mini",
#             messages=[
#                 {"role": "system", "content": "You are Doozy HR Assistant. Answer professionally."},
#                 {"role": "user", "content": f"Data:\n{context}\n\nQuestion: {question}"}
#             ],
#             temperature=0.7
#         )
#         answer = response.choices[0].message.content.strip()
#     except Exception as e:
#         print(f"OpenAI error: {e}")
#         answer = "HR Assistant unavailable."

#     return jsonify({"answer": answer})

