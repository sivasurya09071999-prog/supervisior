
import os
import urllib.parse  # Import this to fix the @ symbol issue
from datetime import datetime
from langchain_openai import ChatOpenAI
from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import create_sql_agent

# --- 1. DATABASE CONNECTION ---
DB_USER = "office_user"
DB_PASSWORD = "Doozy@2020"
DB_HOST = "localhost"
DB_NAME = "office_db1"
DB_PORT = "3306"

# URL-encode the password (this changes @ to %40 so the connection string works)
encoded_password = urllib.parse.quote_plus(DB_PASSWORD)

# Fixed Connection string
mysql_uri = f"mysql+mysqlconnector://{DB_USER}:{encoded_password}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# --- 2. SETUP AI AGENT ---
os.environ["OPENAI_API_KEY"] = "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"

try:
    # Use the URI with the encoded password
    db = SQLDatabase.from_uri(mysql_uri)
    print("✅ Database connected successfully.")
except Exception as e:
    print(f"❌ Database connection failed: {e}")
    exit()

llm = ChatOpenAI(model="gpt-4o", temperature=0)

agent_executor = create_sql_agent(
    llm=llm,
    db=db,
    agent_type="openai-tools",
    verbose=True 
)

def run_chat():
    print("\n--- Employee CRM AI Agent (Dynamic) ---")
    print("Ask me anything about leaves, attendance, or general info.")
    
    while True:
        user_query = input("\nUser: ")
        if user_query.lower() in ['exit', 'quit']:
            break

        # Setting current date context so AI knows "yesterday"
        curr_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        day_name = datetime.now().strftime("%A")
        full_prompt = f"Current Time: {curr_time} ({day_name}). Question: {user_query}"
        
        try:
            response = agent_executor.invoke({"input": full_prompt})
            print(f"\nAI: {response['output']}")
        except Exception as e:
            print(f"\nAI Error: {e}")

if __name__ == "__main__":
    run_chat()