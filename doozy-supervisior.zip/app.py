
# app.py
from flask import Flask
from flask_login import LoginManager, UserMixin
from utils.db import get_db_connection
import os

app = Flask(__name__)
app.secret_key = 'doozy-secure-2025'  # Change this in production!

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'

class User(UserMixin):
    def __init__(self, id, username, role):
        self.id = id
        self.username = username
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    if not conn:
        return None
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, role FROM users WHERE id = %s", (user_id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row:
        return User(row[0], row[1], row[2])
    return None

# Register blueprints
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.attendance import attendance_bp

app.register_blueprint(auth_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(attendance_bp)

def init_db():
    conn = get_db_connection()
    if not conn:
        print("DB connection failed during initialization")
        return
    
    cursor = conn.cursor()
    
    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Attendance table - FIXED
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            action VARCHAR(50) NOT NULL,
            `timestamp` DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_date (user_id, DATE(`timestamp`))
        )
    """)
    
    # Tasks table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            task TEXT NOT NULL,
            progress VARCHAR(10) DEFAULT '0%',
            date DATE NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_user_date (user_id, date),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    
    # Leave applications table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS leave_applications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            leave_date DATE NOT NULL,
            leave_type ENUM('Pre-planned Leave', 'Emergency Leave', 'Permission') NOT NULL,
            purpose TEXT NOT NULL,
            status VARCHAR(20) DEFAULT 'Pending',
            applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_user_leave (user_id, leave_date),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    
    conn.commit()
    cursor.close()
    conn.close()
    print("Database tables initialized successfully.")

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)






# import os
# import urllib.parse  # Import this to fix the @ symbol issue
# from datetime import datetime
# from langchain_openai import ChatOpenAI
# from langchain_community.utilities import SQLDatabase
# from langchain_community.agent_toolkits import create_sql_agent

# # --- 1. DATABASE CONNECTION ---
# DB_USER = "office_user"
# DB_PASSWORD = "Doozy@2020"
# DB_HOST = "localhost"
# DB_NAME = "office_db1"
# DB_PORT = "3306"

# # URL-encode the password (this changes @ to %40 so the connection string works)
# encoded_password = urllib.parse.quote_plus(DB_PASSWORD)

# # Fixed Connection string
# mysql_uri = f"mysql+mysqlconnector://{DB_USER}:{encoded_password}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# # --- 2. SETUP AI AGENT ---
# os.environ["OPENAI_API_KEY"] = "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"

# try:
#     # Use the URI with the encoded password
#     db = SQLDatabase.from_uri(mysql_uri)
#     print("✅ Database connected successfully.")
# except Exception as e:
#     print(f"❌ Database connection failed: {e}")
#     exit()

# llm = ChatOpenAI(model="gpt-4o", temperature=0)

# agent_executor = create_sql_agent(
#     llm=llm,
#     db=db,
#     agent_type="openai-tools",
#     verbose=True 
# )

# def run_chat():
#     print("\n--- Employee CRM AI Agent (Dynamic) ---")
#     print("Ask me anything about leaves, attendance, or general info.")
    
#     while True:
#         user_query = input("\nUser: ")
#         if user_query.lower() in ['exit', 'quit']:
#             break

#         # Setting current date context so AI knows "yesterday"
#         curr_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#         day_name = datetime.now().strftime("%A")
#         full_prompt = f"Current Time: {curr_time} ({day_name}). Question: {user_query}"
        
#         try:
#             response = agent_executor.invoke({"input": full_prompt})
#             print(f"\nAI: {response['output']}")
#         except Exception as e:
#             print(f"\nAI Error: {e}")

# if __name__ == "__main__":
#     run_chat()