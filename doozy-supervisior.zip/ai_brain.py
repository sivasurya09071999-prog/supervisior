# ai_brain.py
import openai
from config import OPENAI_API_KEY

openai.api_key = OPENAI_API_KEY

def ask_doozy_ai(question, context):
    prompt = """
You are Doozy AI — the intelligent HR and Manager assistant for Doozy Office.
You help with employee attendance, tasks, progress, and updates.
Respond professionally, briefly, and naturally.
Summarize information — never show raw database rows or IDs.
If you don't have enough information, say so politely.
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": f"Office Data:\n{context}\n\nQuestion: {question}"}
            ],
            temperature=0.6,
            max_tokens=500
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Sorry, I'm having trouble connecting to the AI service right now. Error: {str(e)}"