# database.py
import mysql.connector
from mysql.connector import Error
from config import MYSQL_CONFIG
from datetime import date

def get_connection():
    try:
        return mysql.connector.connect(**MYSQL_CONFIG)
    except Error as e:
        print(f"DB Connection Error: {e}")
        return None

def init_db():
    conn = get_connection()
    if not conn: return
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50) DEFAULT 'Employee'
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50),
            action VARCHAR(50),
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50),
            task TEXT,
            progress VARCHAR(20),
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    cursor.close()
    conn.close()

def log_attendance(username, action):
    conn = get_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO attendance (username, action) VALUES (%s, %s)", (username, action))
        conn.commit()
        cursor.close()
        conn.close()

def log_task(username, task, progress):
    conn = get_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO tasks (username, task, progress) VALUES (%s, %s, %s)", (username, task, progress))
        conn.commit()
        cursor.close()
        conn.close()

def get_user_for_login(username):
    conn = get_connection()
    if not conn: return None
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, password_hash, role FROM users WHERE username = %s", (username,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    return row

def create_user(username, password_hash):
    conn = get_connection()
    if not conn: return False
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (username, password_hash) VALUES (%s, %s)", (username, password_hash))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except:
        cursor.close()
        conn.close()
        return False

def get_dashboard_data(username):
    conn = get_connection()
    if not conn: return {}
    cursor = conn.cursor(dictionary=True)

    today = date.today().strftime("%Y-%m-%d")
    cursor.execute("""
        SELECT timestamp, action FROM attendance 
        WHERE username = %s AND DATE(timestamp) = %s 
        ORDER BY timestamp ASC
    """, (username, today))
    logs = cursor.fetchall()

    first_login = None
    last_logout = None
    is_logged_in = False

    for log in logs:
        action = log["action"]
        time_str = log["timestamp"].strftime("%H:%M:%S")
        if "LOGIN" in action and first_login is None:
            first_login = time_str
        if action == "LOGOUT":
            last_logout = time_str

    # If there's any login and no logout after the last login → logged in
    if first_login:
        is_logged_in = True
        if last_logout:
            # Check if there's a login after last logout
            last_logout_dt = None
            for log in logs:
                if log["action"] == "LOGOUT":
                    last_logout_dt = log["timestamp"]
            for log in logs:
                if "LOGIN" in log["action"] and log["timestamp"] > last_logout_dt:
                    is_logged_in = True
                    break
            else:
                is_logged_in = False

    cursor.execute("""
        SELECT task, progress, DATE(timestamp) as date, TIME(timestamp) as time 
        FROM tasks WHERE username = %s ORDER BY timestamp DESC LIMIT 10
    """, (username,))
    tasks = cursor.fetchall()

    cursor.close()
    conn.close()

    return {
        "login_time": first_login or "Not logged in today",
        "status": "LOGGED IN" if is_logged_in else "LOGGED OUT",
        "last_logout": last_logout or "N/A",
        "tasks": tasks
    }
def get_all_data_for_ai():
    conn = get_connection()
    if not conn: return "No data available"
    cursor = conn.cursor()
    cursor.execute("SELECT username, action, timestamp FROM attendance ORDER BY timestamp DESC")
    att = cursor.fetchall()
    cursor.execute("SELECT username, task, progress, timestamp FROM tasks ORDER BY timestamp DESC")
    tsk = cursor.fetchall()
    cursor.close()
    conn.close()

    att_str = "\n".join([f"{row[0]} - {row[1]} at {row[2]}" for row in att])
    tsk_str = "\n".join([f"{row[0]} - Task: {row[1]} | Progress: {row[2]} | {row[3]}" for row in tsk])
    return f"Attendance:\n{att_str}\n\nTasks:\n{tsk_str}"